import pandas as pd
from utils.text_cleaner import clean_customer_params


def norm_val(x):
    """
    Function for Normalizing a value by converting it to a string and removing all spaces.
    """
    if pd.isna(x):
        return ""
    return str(x).replace(" ", "")


def update_blr_data(file1_path, file2_path, output_path, modified_output_path, new_rows_output_path):
    """
    Updates file1 based on file2 as follows:
      1. For each row in file2:
           - If the blr_id exists in file1:
               * Compare the following columns (ignoring spaces):
                     "blr_customer_params", "blr_payment_modes", "blr_additional_info",
                     "blr_pmt_amt_exactness", "blr_payment_modes_402", "plan_mdm_requirement",
                     "fetch_requirement"
               * For 'blr_customer_params', apply the regex cleaning logic before comparison.
               * If any difference is found (ignoring spaces), update file1's value for that column with file2's value.
                     - Record the old and new values in a "modified rows" record.
           - If the blr_id does not exist in file1:
               * Append the entire row from file2 to file1.
               * Record this row in a "new rows" record.
      2. After processing, reapply the regex cleaning logic to the entire "blr_customer_params" column in file1.
      3. Save:
           - The updated master file (file1) to output_path.
           - The modified rows (with initial and updated values in separate columns) to modified_output_path.
           - The new rows to new_rows_output_path.
    """
    # Load Data
    df1 = pd.read_excel(file1_path)
    df2 = pd.read_excel(file2_path)

    # Ensure all columns in df1 exist in df2.
    missing_columns = set(df1.columns) - set(df2.columns)
    for col in missing_columns:
        df2[col] = None  # Add missing columns with None values
    # Align column order
    df2 = df2[df1.columns]

    # Drop rows from df2 where "blr_category_name" is "Education fees" (case-insensitive)
    if "blr_category_name" in df2.columns:
        df2 = df2[df2["blr_category_name"].str.lower() != "education fees"]

    # Initialize lists to track modified rows and new rows.
    modified_rows = []  # Will store dictionaries with blr_id, column names, old and new values.
    new_rows = []       # Will store the new row entirely.

    # List of columns to update
    update_columns = [
        "blr_customer_params",
        "blr_payment_modes",
        "blr_additional_info",
        "blr_pmt_amt_exactness",
        "blr_payment_modes_402",
        "plan_mdm_requirement",
        "fetch_requirement"
    ]

    # Process each row in df2
    for _, new_row in df2.iterrows():
        bid = new_row["blr_id"]
        # Check if this blr_id exists in df1
        if bid in df1["blr_id"].values:
            # Get the index (or row) from df1 with the matching blr_id.
            # (Assuming blr_id is unique in df1; if not, process the first occurrence.)
            idx = df1.index[df1["blr_id"] == bid][0]
            # Flag to mark if any update occurs
            row_modified = False
            # Dictionary to record changes for this row
            mod_record = {"blr_id": bid}
            for col in update_columns:
                old_val = df1.at[idx, col]
                new_val = new_row[col]
                # For 'blr_customer_params', apply regex cleaning on new value before comparison
                if col == "blr_customer_params" and pd.notna(new_val):
                    new_val = clean_customer_params(new_val)
                # Compare the normalized values (ignoring spaces) for all update columns.
                if pd.notna(new_val) and norm_val(old_val) != norm_val(new_val):
                    row_modified = True
                    mod_record[col + "_old"] = old_val
                    mod_record[col + "_new"] = new_val
                    # Update df1's value with the new value from file2
                    df1.at[idx, col] = new_val
            # If any column was modified, record the modification
            if row_modified:
                modified_rows.append(mod_record)
        else:
            # This blr_id is new; append it to df1 and record it in new_rows.
            df1 = pd.concat([df1, pd.DataFrame([new_row])], ignore_index=True)
            new_rows.append(new_row)

    # Reapply regex cleaning to the entire "blr_customer_params" column in df1
    if "blr_customer_params" in df1.columns:
        df1["blr_customer_params"] = df1["blr_customer_params"].apply(
            lambda x: clean_customer_params(x) if pd.notna(x) else x)

    # Save the updated master file
    df1.to_excel(output_path, index=False)
    print(f"Updated master file saved to {output_path}")

    # Save modified rows in a separate Excel file.
    if modified_rows:
        df_modified = pd.DataFrame(modified_rows)
        df_modified.to_excel(modified_output_path, index=False)
        print(f"Modified rows saved to {modified_output_path}")
    else:
        print("No modified rows to save.")

    # Save new rows in a separate Excel file.
    if new_rows:
        df_new = pd.DataFrame(new_rows)
        df_new.to_excel(new_rows_output_path, index=False)
        print(f"New rows saved to {new_rows_output_path}")
    else:
        print("No new rows to save.")
