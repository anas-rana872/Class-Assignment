import pandas as pd
import json
import re

"""
def fix_json_string(text):
    if pd.isna(text) or not isinstance(text, str):  # Handle NaN or non-string values
        return text

    # Step 1: Fix missing quotes around keys
    text = re.sub(r'([{,])\s*([a-zA-Z0-9_]+)\s*:', r'\1"\2":', text)

    # Step 2: Remove any extra double quote at the end
    if text.endswith('"'):
        text = text[:-1]

    return text


def clean_customer_params(text):
    fixed_text = fix_json_string(text)  # Fix JSON format issues

    try:
        # Convert fixed string to JSON object (list of dictionaries)
        json_data = json.loads(fixed_text)

        # Iterate through JSON and fix regex patterns
        for item in json_data:
            if "regex" in item and isinstance(item["regex"], str):
                item["regex"] = re.sub(r'\\\\d|\\d', '', item["regex"])  # Remove \d and \\d

        # Convert back to JSON string
        return json.dumps(json_data)

    except json.JSONDecodeError:
        # If parsing fails, return the original text
        return text

"""


def clean_customer_params(text):
    if pd.isna(text) or not isinstance(text, str):  # Handle NaN or non-string values
        return text

    try:
        # Convert string to JSON object (list of dictionaries)
        json_data = json.loads(text)

        # Iterate through JSON and fix regex patterns
        for item in json_data:
            if "regex" in item and isinstance(item["regex"], str):
                item["regex"] = re.sub(r'\\\\d|\\d', '', item["regex"])

        # Convert back to JSON string
        return json.dumps(json_data)

    except json.JSONDecodeError:
        # If parsing fails, return the original text
        return text
