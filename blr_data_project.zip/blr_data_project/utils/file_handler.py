import pandas as pd


def read_excel(file_path):
    return pd.read_excel(file_path, engine='openpyxl')


def write_excel(df, file_path):
    df.to_excel(file_path, index=False, engine='openpyxl')
