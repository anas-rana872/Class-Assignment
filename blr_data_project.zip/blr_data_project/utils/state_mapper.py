import json


def load_state_mapping(json_path):
    """Loads state mapping from a JSON file."""
    with open(json_path, "r", encoding="utf-8") as f:
        state_mapping_list = json.load(f)

    # Convert list of dictionaries into a mapping dictionary
    state_mapping = {item["blr_coverage"]: item["full_state_name"] for item in state_mapping_list if
                     "blr_coverage" in item and "full_state_name" in item}

    return state_mapping


def map_state_codes(df, json_path):
    state_mapping = load_state_mapping(json_path)  # Load mapping dictionary

    # Ensure column and mapping keys are lowercase for consistency
    state_mapping = {k.lower(): v for k, v in state_mapping.items()}
    df["blr_coverage"] = df["blr_coverage"].str.lower()

    df["full_state_name"] = df["blr_coverage"].map(state_mapping)

    return df
